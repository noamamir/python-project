"""Set of timer (stopwatch & countdown) widgets for tkinter"""

__version__ = "0.1.0"

from tktimer.tktimer import Countdown, Stopwatch
